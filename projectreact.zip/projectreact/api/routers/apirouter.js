const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const productc=require('../controllers/productcontroller')
const upload=require('../helpers/multer')
const cartc=require('../controllers/cartcontroller')



router.post('/register',regc.register)
router.post('/login',regc.logincheck)
router.post('/addproduct',upload.single('img'),productc.addproduct)
router.get('/allproducts',productc.allproducts)
router.get('/singleproduct/:id',productc.singleproduct)
router.put('/productupdate/:id',upload.single('img'),productc.productupdate)
router.get('/stockproducts',productc.stockproducts)
router.post('/cart',productc.cart)
router.delete('/adminproductdelete/:id',productc.adminproductdelete)

router.post('/checkout/:username',cartc.checkout)









module.exports =router