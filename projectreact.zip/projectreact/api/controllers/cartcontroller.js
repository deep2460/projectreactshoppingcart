const Cart=require('../models/cart')
const Product=require('../models/products')




exports.checkout=async(req,res)=>{
    //console.log(req.params.username)
    //console.log(req.body)
    const username=req.params.username
     const cartitem=req.body 
    for(let id in cartitem){
        //console.log(id)
        //console.log(cartitem[id])
        const qty=cartitem[id]
        //console.log(qty)
        const ids=id
        //console.log(ids)
        const [record]=await Product.find({_id:{$in:[ids]}})
        //console.log(record.price)
        const name=record.name
        let itemprice=record.price 
        let totalitemprice=itemprice*qty

       const cartrecord= new Cart({name:name,qty:qty,price:totalitemprice})
       //console.log(cartrecord)
    }  
}