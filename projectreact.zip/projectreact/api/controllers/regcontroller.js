const Reg=require('../models/reg')
const bcrypt=require('bcrypt')

exports.register=async(req,res)=>{
    //console.log(req.body)
    
    const {username,password}=req.body
    const convertedpass= await bcrypt.hash(password,10)
    //console.log(convertedpass)
    const usercheck=await Reg.findOne({username:username})
    //console.log(usercheck)
    try{
        if(usercheck==null){
        const record=await new Reg({username:username,password:convertedpass})
        record.save()
        //console.log(record)
        res.json({
            status:201,
            apiData:record,
            message:`${username} has been created Successfully`  
        })
       }else{
        res.json({
            status:400,
             message:`${username} is already taken`
        })
       }
    }catch(error){
        res.json({
            status:400,
            message:error.message
        })
    }
}

exports.logincheck=async(req,res)=>{
    //console.log(req.body)
    const{username,password}=req.body
 try{
    const record=await Reg.findOne({username:username})
    //console.log(record)
    if(record!==null){
        const passwordcheck=await bcrypt.compare(password,record.password)
        //console.log(passwordcheck)
        if(passwordcheck){
          res.json({
            status:200,
            apiData:record.username
          })
        }else{
            res.json({
                status:400,
                message:"Wrong Password"
            })
        }
    }else{
          res.json({
            status:400,
            message:"Wrong Username"
          })
    }
 }catch(error){
    res.json({
        status:400,
        message:error.message
    })
 }
}



