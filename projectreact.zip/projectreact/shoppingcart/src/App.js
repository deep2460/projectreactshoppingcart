import { BrowserRouter as Router,Routes,Route } from 'react-router-dom'
import Login from './componants/Login';
import Reg from './componants/Reg';
import Header from './componants/Header';
import { Contextapi } from './Contextapi';
import { useEffect, useState } from 'react';
import Products from './componants/Products';
import Dashboard from './componants/Dashboard';
import Adminproducts from './componants/Adminproducts';
import Adminnewproduct from './componants/Adminnewproduct';
import Adminproductupdate from './componants/Adminproductupdate';
import Cart from './componants/Cart';
import Adminusermanage from './componants/Adminusermanage';
function App() {
  const[cart,setCart]=useState('')
  useEffect(()=>{localStorage.setItem('cart',JSON.stringify(cart))},[cart])
  
  const [loginname,setLoginname]=useState(localStorage.getItem('loginname'))
  return ( 
   <Router>
    <Contextapi.Provider value={{loginname,setLoginname,cart,setCart}}>
    <Header/>
    <Routes>
      <Route path='/' element={<Login/>}></Route>
      <Route path='/reg' element={<Reg/>} ></Route>
      <Route path='/products' element={<Products/>}></Route>
      <Route path='/dashboard' element={<Dashboard/>}></Route>
      <Route path='/adminproducts' element={<Adminproducts/>}></Route>
      <Route path='/adminnewproduct' element={<Adminnewproduct/>}></Route>
      <Route path='/adminproductupdate/:id' element={<Adminproductupdate/>}></Route>
      <Route path='/cart' element={<Cart/>} ></Route>
      <Route path='/adminusermanage' element={<Adminusermanage/>} ></Route>
      
    </Routes>
    </Contextapi.Provider>
   </Router>
   );
}

export default App;