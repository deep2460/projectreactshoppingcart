import { useState } from "react";
import { Link } from "react-router-dom";

function Reg() {
    const[username,setUsername]=useState('')
    const[password,setPassword]=useState('')
    const[message,setMessage]=useState('')
    function handleform(e){
        e.preventDefault()
        //console.log(username,password)
        const formdata={username,password}
        fetch('/api/register',{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body: JSON.stringify(formdata)
        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===201){
              setMessage(data.message)
            }else{
               setMessage(data.message)
            }
        })
        
    } 
    return (
        
        <section id="login">
        <div className="container">
            <div className="row">
                <div className="col-md-4"></div>
                <div className="col-md-4">
                    <h2>Register Here</h2>
                    <p>{message}</p>
                    <form onSubmit={(e)=>{handleform(e)}}>
                        <label>Username/Email</label>
                        <input type="text" className="form-control" 
                        value={username}
                        onChange={(e)=>{setUsername(e.target.value)}}
                        />
                        <label>Password</label>
                        <input type="text" className="form-control" 
                        value={password}
                        onChange={(e)=>{setPassword(e.target.value)}}
                        />
                        <button type="submit" className="form-control btn btn-success mt-2">Register</button>
                    </form>
                    <Link to='/'><button className="form-control btn btn-primary mt-4">Already Have Account? Login Here </button></Link>
                </div>
                <div className="col-md-4"></div>
            </div> 
        </div>

    </section>
     );
}

export default Reg;