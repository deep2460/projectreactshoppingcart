import { useNavigate, useParams } from "react-router-dom";
import Left from "./Left";
import { useEffect, useState } from "react";

function Adminproductupdate() {
    const[message,setMessage]=useState('')
    const navigate=useNavigate()
    const [name, setName] = useState('')
    const [desc, setDesc] = useState('')
    const [price, setPrice] = useState('')
    const [qty, setQty] = useState('')
    const [img, setImg] = useState('')
    const[status,setStatus]=useState('')
    const { id } = useParams()
    useEffect(()=>{
        fetch(`/api/singleproduct/${id}`).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
               setName(data.apiData.name)
               setDesc(data.apiData.desc)
               setPrice(data.apiData.price)
               setQty(data.apiData.qty)
               setImg(data.apiData.img)
               setStatus(data.apiData.status)
            }else{
                setMessage(data.message)
            }
        })
    },[])

    function handleform(e){
        e.preventDefault()
        //console.log(name,desc,price,qty,status)
        //console.log(img)
        const data=new FormData()
        data.append('name',name)
        data.append('desc',desc)
        data.append('price',price)
        data.append('qty',qty)
        data.append('status',status)
        data.append('img',img)
        fetch(`/api/productupdate/${id}`,{
            method:"PUT",
            body:data
        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                setMessage(data.message)
                alert("Product updated successfully")
                navigate('/adminproducts')
            }else{
                setMessage(data.message)
            }
        })
        
    }
    return (

        <section id="mid">
            <div className="container">
                <div className="row">
                    <Left />
                    <div className="col-md-9">
                        <h2>Product Update {id}</h2>
                        <p>{message}</p>

                        <form onSubmit={(e)=>{handleform(e)}}>
                            <label>Product Name</label>
                            <input type="text" className="form-control"
                            value={name}
                            onChange={(e)=>{setName(e.target.value)}}
                            />
                            <label>Product Description</label>
                            <input type="text" className="form-control"
                             value={desc}
                             onChange={(e)=>{setDesc(e.target.value)}}
                            />
                            <label>Product Price</label>
                            <input type="number" className="form-control"
                            value={price}
                            onChange={(e)=>{setPrice(e.target.value)}}
                            />
                            <label>Product Quantity</label>
                            <input type="number" className="form-control"
                             value={qty}
                             onChange={(e)=>{setQty(e.target.value)}}
                            />
                            <label>Product Status</label>
                            <select className="form-select" value={status}
                            onChange={(e)=>{setStatus(e.target.value)}}
                            >
                                <option value="OUT-STOCK">OUT-STOCK</option>
                                <option value="IN-STOCK">IN-STOCK</option>
                            </select>
                            <label>Product Image</label>
                            <input type="file"
                            onChange={(e)=>{setImg(e.target.files[0])}}
                            />
                            <button className="form-control btn btn-danger mt-2"> Update Product</button>

                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Adminproductupdate;