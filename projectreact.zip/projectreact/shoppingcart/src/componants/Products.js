import { useEffect, useState } from 'react';
import Productstr from './Productstr';
function Products() {
    const[message,setMessage]=useState('')
    const[products,setProducts]=useState([])
    useEffect(()=>{
        fetch('/api/stockproducts').then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
               setProducts(data.apiData)
            }else{
                setMessage(data.message)
            }
        })
    },[])
    
    return (
        <>
        
        <Productstr product={products}  message={message} />
        
        </>
    );
}

export default Products;