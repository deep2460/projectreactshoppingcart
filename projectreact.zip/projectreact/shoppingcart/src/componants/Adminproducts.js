import { Link, useNavigate, } from "react-router-dom";
import Left from "./Left";
import { useContext, useEffect, useState } from "react";
import { Contextapi } from "../Contextapi";

function Adminproducts() {
    const {loginname}=useContext(Contextapi)
    let navigate=useNavigate()
    const[message,setMessage]=useState('')
    const[products,setProducts]=useState([])
    
    
    useEffect(()=>{
        fetch('/api/allproducts').then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                setProducts(data.apiData)
                if(!loginname){
                    navigate('/')
                }
                
            }else{
                setMessage(data.message)
            }
        })
        },[])

        function handleproductdelete(e,id,result){
            
              //console.log(id)
              fetch(`/api/adminproductdelete/${id}`,{
                method:"delete"
            }).then((result)=>{return result.json()}).then((data)=>{
                //console.log(data)
                if(data.status===200){
                    alert(data.message)
                    const filterproduct= products.filter((allproducts)=>(allproducts._id!==id))
                    //setProducts(filterproduct)
                     
                    return filterproduct
                //console.log(filterproduct)
                    
                }else{
                    setMessage(data.message)
                }
            })        
        }

        useEffect(()=>{
            //console.log(id)
           
        },[])

    return ( 
        <section id="mid">
        <div className="container">
            <div className="row">
                <Left/>
                <div className="col-md-9">
                <h2>Products Management</h2>
                <p>{message}</p>
                <Link to='/adminnewproduct'><button className="btn btn-danger form-control mt-2 mb-2">ADD NEW PRODUCTS</button></Link>
                <table className="table table-hover">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Product Name</th>
                            <th>Product Description</th>
                            <th>Product Image</th>
                            <th>Product Price</th>
                            <th>Product Quantity</th>
                            <th>Product status</th>
                            <th>Action</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {products.map((result,sn)=>(
                            <tr key={result._id}>
                            <td>{sn+1}</td>
                            <td>{result.name}</td>
                            <td>{result.desc}</td>
                            <td><img src={`/upload/${result.img}`} alt="" /></td>
                            <td>{result.price}</td>
                            <td>{result.qty}</td>
                            <td>{result.status}</td>
                            <td><Link to={`/adminproductupdate/${result._id}`}><button className="btn btn-success">Update</button></Link></td>
                            <td><button className="btn btn-success" onClick={(e)=>{handleproductdelete(e,result._id,result)}}>Delete</button></td>
                            </tr>  
                        ))}
                        
                        
                        
                    </tbody>
                </table>
                </div>
            </div>
        </div>
        </section> 
       
     );
}

export default Adminproducts;