import { useContext } from "react";
import { Contextapi } from "../Contextapi";

function Productstr(props) {
    const{product,message}=props
    //const {message}=props
    const{cart,setCart}=useContext(Contextapi)

    function handleaddcart(e,productid){
        //console.log(productid)
        
        let _cart={...cart}
        if(!_cart.item){
        _cart.item={}
        }
        if(!_cart.item[productid]){
            _cart.item[productid]=1
        }else{
            _cart.item[productid]+=1
        }
        setCart(_cart)

        if(!_cart.totalitems){
            _cart.totalitems=1
        }else{
            _cart.totalitems+=1
        }
        setCart(_cart)
        //console.log(cart)
    }
    return ( 
        <section id="product">
            <div className="container">
                <div className="row">
                    <p>{message}</p>
                    {product.map((result,key)=>(
                    <div className="col-md-3" key={result._id}>
                        <div className="card" style={{ width: "18rem" }} >
                            <img src={`/upload/${result.img}`} className="card-img-top" alt="" />
                            <div className="card-body">
                                <h5 className="card-title">{result.name}</h5>
                                <p className="card-text">{result.desc} </p>
                                <p className="card-text">Price: rs {result.price} </p>
                                <button to='' className="btn btn-primary me-2" > Details</button>
                                <button  className="btn btn-success" onClick={(e)=>{handleaddcart(e,result._id)}}>Add Cart</button>
                            </div>
                        </div>
                    </div>
                    ))}
                    
                </div>
            </div>
        </section>
     );
}

export default Productstr;