import { useContext, useEffect, useState } from "react";
import { Contextapi } from "../Contextapi";
import { useNavigate } from "react-router-dom"


function Cart() {
    let totalamount=0
    const[message,setMessage]=useState('')
    const[products,setProducts]=useState([])
    const{loginname,cart,setCart}=useContext(Contextapi)
    let navigate=useNavigate()
    
    useEffect(()=>{
        if(!cart.item){
            return
        }
        fetch('/api/cart',{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({ids:Object.keys(cart.item)})
        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                setProducts(data.apiData)
            }else{
                setMessage(data.message)
            }
        })
    },[])

    function handleqty(id){
        //console.log (cart.item[id])
        return cart.item[id]     
        //qty capture and return to run function
    }

    function handleincrement(e,id,stockqty){
        let currentqty=handleqty(id)
        if(currentqty===stockqty){
            //compare stock qty with product purchase qty
            alert("you have to reached max quantity")
            return    
        }
        let _cart={...cart}
        _cart.item[id]=currentqty+1
        _cart.totalitems+=1

        setCart(_cart)  //assign clone value into main varible
        

    }

    function handledecrement(e,id){
        let currentqty=handleqty(id)
        if(currentqty===1){
            alert("You have to reached minimum quantity")
            return
        }
        let _cart={...cart}
        _cart.item[id]=currentqty-1
        _cart.totalitems-=1

        setCart(_cart)
    }

    function handleprice(id,price){
        let currenttotalprice=handleqty(id)*price
            totalamount+=currenttotalprice //reassignment in global variable:totalamount
        return currenttotalprice
    }

    function handleitemremove(e,id){
        //console.log(id) 
           // let _cart={...cart}
            //console.log(_cart)
           // let currentqty=handleqty(id)
            //return _cart.filter((abc)=>(abc._id!==id))
             // _cart.totalitems=-currentqty
               // setCart(_cart)
            }     
                 
               
    

    function handlecheckout(e){
        fetch(`/api/checkout/${loginname}`,{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(cart.item)
        })
        setCart('')
        navigate('/products')
    }
    return ( 
        <section id="cart">
            {products.length!==0?
            <>
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <h2>Cart</h2>
                        <p>{message}</p>
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                <th>S.No</th>
                                <th>Product name</th>
                                <th>Product Quantity</th>
                                <th>Product Price</th>
                                <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {products.map((result,sn)=>(
                                    <tr key={result._id}>
                                    <td>{sn+1}</td>
                                    <td>{result.name}</td>
                                    <td><button className="btn btn-outline-danger me-2" onClick={(e)=>{handledecrement(e,result._id)}}>-</button>{handleqty(result._id)}<button className="btn btn-outline-success ms-2" onClick={(e)=>{handleincrement(e,result._id,result.qty)}}>+</button></td>
                                    <td>{handleprice(result._id,result.price)}</td>
                                    <td  ><button onClick={(e)=>{handleitemremove(e,result._id)}}>Remove</button></td>
                                    </tr>
                                ))}

                                <tr>
                                    <td colSpan="6">Toatal Amount:- RS {totalamount}/-</td>
                                </tr>

                                <tr>
                                    <td colSpan="12"><button className="form-control btn btn-primary" onClick={(e)=>{handlecheckout(e,cart.item)}}>CHECKOUT</button></td>
                                    
                                </tr>
                                    
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            </>
            :
            <>
            <div className="container">
                <div className="row" id="row">
                    <div className="col-md-4"></div>
                    <div className="col-md-4">
                    <img src="/media/transparent-empty-cart.png" alt="" />
                    </div>
                    <div className="col-md-4"></div>
                    
                </div>
            </div>
            
            </>
            }
        </section>

     );
}

export default Cart;