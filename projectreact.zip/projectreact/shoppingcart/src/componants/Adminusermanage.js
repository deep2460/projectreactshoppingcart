import Left from "./Left";

function Adminusermanage() {
    return (
        <section id="mid">
        <div className="container">
            <div className="row">
               <Left/>
                <div className="col-md-9">
                    <h2>User Management</h2>
                </div>
            </div>
        </div>
        </section> 
        
     );
}

export default Adminusermanage;