import { useState } from "react";
import Left from "./Left";
import { useNavigate } from "react-router-dom";


function Adminnewproduct() {
    const [name, setName] = useState('')
    const [desc, setDesc] = useState('')
    const [price, setPrice] = useState('')
    const [qty, setQty] = useState('')
    const [productimg, setProductimg] = useState('')
    const[message,setMessage]=useState('')
    const navigate=useNavigate()
    

    function handleform(e) {
        e.preventDefault()
        //console.log(name,desc,qty,price)
        //console.log(productimg)
        let data = new FormData()
        data.append('name', name)
        data.append('desc', desc)
        data.append('price', price)
        data.append('qty', qty)
        data.append('img', productimg)
        fetch('/api/addproduct',{
            method:"POST",
            body:data
        }).then((result)=>{ return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===201){
            //setMessage(data.message)
            alert(data.message)
            navigate('/adminproducts')
            
            }else{
            setMessage(data.message)
            }
        })

    }
    

    return (
        <section id="mid">
            <div className="container">
                <div className="row">
                    <Left />
                    <div className="col-md-9">
                        <h2>ADD PRODUCTS HERE</h2>
                        <p>{message}</p>
                        <form onSubmit={(e) => { handleform(e) }}>
                            <label>Product Name</label>
                            <input type="text" className="form-control"
                                value={name}
                                onChange={(e) => { setName(e.target.value) }}
                            />
                            <label>Product Description</label>
                            <input type="text" className="form-control"
                                value={desc}
                                onChange={(e) => { setDesc(e.target.value) }}
                            />
                            <label>Product Price</label>
                            <input type="number" className="form-control"
                                value={price}
                                onChange={(e) => { setPrice(e.target.value) }}
                            />
                            <label>Product Quantity</label>
                            <input type="number" className="form-control"
                                value={qty}
                                onChange={(e) => { setQty(e.target.value) }}
                            />
                            <label>Product Image</label>
                            <input type="file" className="form-control"
                                onChange={(e) => { setProductimg(e.target.files[0]) }}
                            />
                            <button className="form-control btn btn-danger mt-2"> Add Products</button>

                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Adminnewproduct;